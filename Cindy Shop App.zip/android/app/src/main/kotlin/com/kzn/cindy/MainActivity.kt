package com.kzn.cindy

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
